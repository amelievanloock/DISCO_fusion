import numpy as np
from typing import Dict, List, Optional
from dataclasses import dataclass
from ultralytics import YOLO
from core.frame_management import FrameData
from core.vehicle_detection import VehicleDetection

@dataclass
class LicensePlateDetection:
    bbox: List[float]                              # [x1, y1, x2, y2] relative to vehicle crop
    confidence: float                              # Detection confidence
    vehicle_det: VehicleDetection                  # Reference to parent vehicle detection
    absolute_coords: Optional[List[float]] = None  # Coordinates in original frame

class LicensePlateDetector:
    
    def __init__(self, model_path: str, device: str = 'cuda',
                 conf_threshold: float = 0.5, video_processor=None):
        
        self.device = device
        self.conf_threshold = conf_threshold
        self.video_processor = video_processor
        
        try:
            self.model = YOLO(model_path).to(device)
            print(f"Vehicle detection model loaded: {model_path}")
        except Exception as e:
            raise RuntimeError(f"Error loading detection model: {e}")
        
        self.processed_crops = 0
        self.total_detections = 0
    
    def detect_batch(self, vehicle_crops: List[np.ndarray], parent_detections: List[VehicleDetection]) -> Dict[int, List[LicensePlateDetection]]:
        """
        Detect license plates in a batch of vehicle crops.
        
        Args:
            vehicle_crops: List of cropped images of vehicles
            parent_detections: Original vehicle detection information
            
        Returns:
            Dictionary of license plate detections by vehicle index
        """
        if not vehicle_crops:
            return {}
        
        results = self.model(vehicle_crops, verbose=False)
        
        detections_dict = {}
        
        for idx, (result, parent_det) in enumerate(zip(results, parent_detections)):
            
            boxes = result.boxes
            if len(boxes) == 0:
                continue
            
            best_conf = -1
            best_detection = None
            
            for box, conf in zip(boxes.xyxy, boxes.conf):
                if conf > self.conf_threshold or conf > best_conf:
                    
                    crop_coords = box.cpu().tolist()
                    scaled_frame_coords = self._convert_to_frame_coords(
                        crop_coords, parent_det.bbox
                    )
                    original_coords = self.video_processor.transform_coordinates(
                        scaled_frame_coords, inverse=True
                    )
                    
                    detection = LicensePlateDetection(
                        bbox=crop_coords,
                        confidence=conf.item(),
                        vehicle_det=parent_det,
                        absolute_coords=original_coords
                    )
                    
                    best_detection = detection
                    best_conf = conf
        
            if best_detection is not None:
                detections_dict[idx] = best_detection
                
        self.processed_crops += len(vehicle_crops)
        self.total_detections += len(detections_dict)            
            
        return detections_dict
        
    
    def detect(self, vehicle_crop: np.ndarray, parent_detection: VehicleDetection) -> LicensePlateDetection:
        """
        Detect a single license plate (most confident) in a vehicle crop.
        This implementation is not perfect as it may introduce errors if vehicle
        bounding boxes overlap.

        Args:
            vehicle_crop: Cropped image of vehicle
            parent_detection: Original vehicle detection information

        Returns:
            License plate detection information
        """
        results = self.model(vehicle_crop, verbose=False)
        
        boxes = results[0].boxes
        
        if len(boxes) == 0:
            self.processed_crops += 1
            return None
        
        best_detection = None
        highest_conf = -1
        
        for box, conf in zip(boxes.xyxy, boxes.conf):
            if conf < self.conf_threshold and conf > highest_conf:
                continue
            crop_coords = box.cpu().tolist()
            
            scaled_frame_coords = self._convert_to_frame_coords(
                crop_coords, parent_detection.bbox
            )
            
            original_coords = self.video_processor.transform_coordinates(
                scaled_frame_coords, inverse=True
            )
            
            detection = LicensePlateDetection(
                bbox=crop_coords,  
                confidence=conf.item(),
                vehicle_det=parent_detection,
                absolute_coords=original_coords,  
            )
            
            best_detection = detection
            highest_conf = conf
            
        
        self.processed_crops += 1
        if best_detection is not None:
            self.total_detections += 1
        
        return best_detection

    def _convert_to_frame_coords(self, crop_coords: List[float], vehicle_bbox: List[float]) -> List[float]:
        """
        Convert coordinates from crop space to scaled frame space.
        
        Args:
            crop_coords: Coordinates within vehicle crop
            vehicle_bbox: Vehicle bounding box in scaled frame
            
        Returns:
            Coordinates in scaled frame space
        """
        return [
            vehicle_bbox[0] + crop_coords[0],  
            vehicle_bbox[1] + crop_coords[1],  
            vehicle_bbox[0] + crop_coords[2],  
            vehicle_bbox[1] + crop_coords[3]  
        ]
