from typing import Dict, List
from dataclasses import dataclass
from ultralytics import YOLO
from core.frame_management import FrameData

@dataclass
class VehicleDetection:
    """
    Container for detection results that includes all necessary information
    about a detected vehicle.
    """
    bbox: List[float]               # [x1, y1, x2, y2] in current resolution
    confidence: float               # Detection confidence score
    class_id: int                   # Vehicle class
    frame_idx: int                  # Frame where detection occurred
    original_coords: List[float]    # Coordinates in original video resolution

class VehicleDetector:
    """
    Handles vehicle detection in video frames using YOLO.
    Processes frames in batches for efficiency and maintains
    coordinate system consistency.
    """
    # Class for vehicle categories
    VEHICLE_CLASSES = {2, 7}  # 2: car, 7: truck
    
    def __init__(self, model_path: str, device: str = 'cuda',
                 conf_threshold: float = 0.3, video_processor=None):
        """
        Initialize the vehicle detector.

        Args:
            model_path: Path to YOLO model weights
            device: Device for inference ('cuda' or 'cpu')
            conf_threshold: Confidence threshold for detections
            video_processor: VideoProcessor object to coordinate transformations
        """
        self.device = device
        self.conf_threshold = conf_threshold
        self.video_processor = video_processor
        
        try:
            self.model = YOLO(model_path).to(device)
            print(f"Vehicle detection model loaded: {model_path}")
        except Exception as e:
            raise RuntimeError(f"Error loading detection model: {e}")
        
        self.frames_processed = 0
        self.total_detections = 0
    
    def process_batch(self, frames_data: List[FrameData]) -> Dict[int, List[VehicleDetection]]:
        """
        Process a batch of frames and return detections.
        
        Args:
            frames_data: List of FrameData objects from VideoProcessor
            
        Returns:
            Dictionary mapping frame indices to lists of detections
        """
        if not frames_data:
            return {}
        
        # Extract frames for batch processing
        #TODO: We pass the model the frames that are in the buffer -> in some cases this may not be good.
        frames = [fd.frame for fd in frames_data]
        
        results = self.model(frames, verbose=False)
        
        # Process results frame by frame
        detections_by_frame = {}
        for frame_data, result in zip(frames_data, results):
            frame_idx = frame_data.frame_idx
            boxes = result.boxes
            
            detections_by_frame[frame_idx] = []
            
            # Process each detection
            for box, cls, conf in zip(boxes.xyxy, boxes.cls, boxes.conf):
                if int(cls) in self.VEHICLE_CLASSES and conf > self.conf_threshold:
                    
                    bbox = box.cpu().tolist() # Coordinates in processing resolution
                    
                    # Coordinates in original resolution
                    original_coords = self.video_processor.transform_coordinates(bbox, inverse=True)
                    
                    detection = VehicleDetection(
                        bbox=bbox,
                        confidence=conf.item(),
                        class_id=int(cls.item()),
                        frame_idx=frame_idx,
                        original_coords=original_coords
                    )
                    
                    detections_by_frame[frame_idx].append(detection)
                    self.total_detections += 1
            
            self.frames_processed += 1
        
        return detections_by_frame