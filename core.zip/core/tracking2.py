import torch
import numpy as np
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import dataclass
from strongsort import StrongSORT
from models.vehicle_tracking.model import ft_net
from core.vehicle_detection import VehicleDetection

@dataclass
class Track:
    track_id: int                 # Unique identifier for the track
    bbox: List[float]             # [x1, y1, x2, y2] in processing resolution
    original_coords: List[float]  # Coordinates in original video resolution
    frame_idx: int                # Current frame index
    confidence: float             # Confidence score

class VehicleTracker:
    """
    Handles vehicle tracking using StrongSORT with a custom ReID model.
    Maintains track consistency across frames and handles coordinate transformations.
    """
    def __init__(self, 
                 reid_weights_path: str,
                 strongsort_weights_path: str,
                 device: str = 'cuda',
                 video_processor=None):
        """
        Initialize the vehicle tracker with custom ReID model and StrongSORT.

        Args:
            reid_weights_path: Path to ReID model weights
            strongsort_weights_path: Path to StrongSORT weights
            device: Device for inference
            max_age: Maximum frames to keep track without detection
            n_init: Frames needed to confirm track
        """
        self.device = device
        self.video_processor = video_processor
        
        self.reid_model = self._initialize_reid_model(reid_weights_path)
        
        # Initialize StrongSORT tracker
        # TODO: tracking parameters should be passed from the config file
        self.tracker = StrongSORT(
            model_weights=Path(strongsort_weights_path),
            device=device,
            max_dist=0.3,            
            max_iou_distance=0.7,    
            max_age=600,
            n_init=20,
            nn_budget=600,
            fp16=False
        )
        
        # Override StrongSORT's ReID model with our custom model for vehicle tracking
        self.tracker.model.model = self.reid_model
    
    
    def _initialize_reid_model(self, weights_path: str) -> torch.nn.Module:
        """Initialize and configure the ReID model."""
        num_classes = 576  # VeRi dataset classes
        model = ft_net(num_classes, stride=1)
        
        state_dict = torch.load(weights_path, map_location=torch.device('cpu'))
        new_state_dict = {k.replace('module.', ''): v for k, v in state_dict.items()}
        model_dict = model.state_dict()
        new_state_dict = {k: v for k, v in new_state_dict.items() if k in model_dict}
        
        model.load_state_dict(new_state_dict, strict=False)
        model.classifier.classifier = torch.nn.Sequential()
        model = model.to(self.device).eval()
        
        return model
    
    def update(self, frame: np.ndarray, 
               detections: List[VehicleDetection], 
               frame_idx: int) -> List[Track]:
        """
        Update tracker with new detections.
        
        Args:
            frame: Current video frame
            detections: List of detections in the current frame
            frame_idx: Current frame index
            
        Returns:
            List of current tracks
        """
        if not detections:
            dets = torch.empty((0, 6))
        else:
            dets = np.array([
                [d.bbox[0], d.bbox[1], d.bbox[2], d.bbox[3],
                 d.confidence, 0] for d in detections
            ])
            dets = torch.from_numpy(dets)
        
        tracks_raw = self.tracker.update(dets, frame)
        
        tracks = []
        for t in tracks_raw:
            bbox = t[:4].tolist()
            original_coords = self.video_processor.transform_coordinates(
                coords=bbox,
                inverse=True
            )
            
            track = Track(
                track_id=int(t[4]),
                bbox=bbox,
                original_coords=original_coords,
                frame_idx=frame_idx,
                confidence=float(t[5])
            )
            tracks.append(track)
        
        return tracks