import torch
import numpy as np
import math    
from torchvision import transforms
from scipy.optimize import linear_sum_assignment
from strongsort.sort.track import Track as _Track
from strongsort.sort import kalman_filter, linear_assignment, iou_matching

from strongsort import StrongSORT as _BaseStrongSORT
from paddleocr import PaddleOCR
from ultralytics import YOLO
from strongsort.sort.detection import Detection
import torch.nn.functional as F
from typing import Tuple
import cv2
import torch.nn as nn
from typing import List


MODEL_PATH = "/home/usuaris/imatge/manel.davins/disco/DUM-monitoring/models/license_plate_detection/yolov8s-license-plate.pt"

def initialize_models(device_type):
    lp_det = YOLO(MODEL_PATH).to(device_type)
    use_gpu = (device_type=="cuda")
    ocr = PaddleOCR(use_angle_cls=True, lang='en', use_gpu=False)
    return lp_det, ocr


def yolo_xyxy(det):
    if hasattr(det,'boxes'):
        return det.boxes.xyxy.cpu().numpy()
    return np.empty((0,4))

    

def preprocess_image_forReID(
    image: np.ndarray,
    size: Tuple[int, int],
    fp16: bool = False
) -> torch.Tensor:
    """
    Generic preprocessor for ReID crops (vehicle or plate).

    Args:
      image: HxWx3 BGR numpy array (as OpenCV gives you).
      size:  (H, W) output resolution for this model.
      fp16:  cast to half precision if True.

    Returns:
      A 4D torch.Tensor of shape [1, 3, H, W].
    """
    # If someone passed a torch.Tensor, convert to numpy
    if isinstance(image, torch.Tensor):
        image = image.squeeze(0).permute(1,2,0).cpu().numpy()

    # Ensure uint8 BGR ? RGB
    if image.dtype != np.uint8:
        image = np.uint8(image * 255)
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    # Resize
    image_rgb = cv2.resize(image_rgb, (size[1], size[0]))

    # To tensor & normalize
    pipeline = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5]*3, std=[0.5]*3),
    ])
    tensor = pipeline(image_rgb).unsqueeze(0)
    if fp16:
        tensor = tensor.half()
    return tensor


def extract_lp_embedding(model, lp_crop: np.ndarray, device: torch.device, fp16: bool=False) -> torch.Tensor:
    preprocessed = preprocess_image_forReID(lp_crop, size=(384,128), fp16=fp16)
    preprocessed = preprocessed.to(device)
    with torch.no_grad():
        embedding = model(preprocessed)
    # If the model returns a list, select the first element.
    if isinstance(embedding, list):
        embedding = embedding[0]
    # Optionally, ensure the embedding is a tensor.
    if not isinstance(embedding, torch.Tensor):
        embedding = torch.as_tensor(embedding, device=device)
    return embedding


def extract_veh_embedding(
    model: torch.nn.Module,
    crop: np.ndarray,
    device: torch.device,
    fp16: bool = False
) -> torch.Tensor:
    # specify the size your vehicle model expects, e.g. (256,128)
    tensor = preprocess_image_forReID(crop, size=(256,128), fp16=fp16)
    tensor = tensor.to(device)
    with torch.no_grad():
        emb = model(tensor)
    if isinstance(emb, (list,tuple)):
        emb = emb[0]
    return emb.squeeze(0)



def lp_get_features_with_weights(dets, img, veh_model, lp_model, lp_det, ocr, device, fp16=False):
    """
    dets:  either a torch.Tensor of shape (N,4) or a numpy.ndarray (N,4)
    img:   the full image array
    """
    # --- BEGIN PATCH ---
    print(">>> entering lp_get_features_with_weights")
    # unify detections into a numpy array of ints
    if torch.is_tensor(dets):
        arr = dets.detach().cpu().numpy()
    else:
        arr = dets
    # now arr is np.ndarray, float or int
    arr = arr.astype(float)   # ensure float for slicing below
    # --- END PATCH ---

    out = []
    h, w = img.shape[:2]
    for i in range(arr.shape[0]):
        # use the already-numpy arr
        xy = arr[i, :4].astype(int)
        x1, y1, x2, y2 = np.clip(xy, [0,0,0,0], [w,h,w,h])
        vcrop = img[y1:y2, x1:x2]
        # Vehicle embedding
        vemb = extract_veh_embedding(veh_model, vcrop, device, fp16)
        vemb = F.normalize(vemb.squeeze(0), dim=-1)
        # Plate detection & crop   
        res = lp_det(vcrop, verbose=False)[0]
        #boxes = yolo_xyxy(res)
        # get both boxes and confidences
        boxes = res.boxes.xyxy.cpu().numpy()
        confs = res.boxes.conf.cpu().numpy()
        if len(confs):
            print(f"[DEBUG] YOLO returned {len(confs)} plates, confidences = {confs}")
        else:
            print("[DEBUG] YOLO found no plates ? lp_conf=0.0")
        if len(boxes):
            bx1, by1, bx2, by2 = boxes[0].astype(int)
            crop    = vcrop[by1:by2, bx1:bx2]
            lp_conf = float(confs[0])
            
        else:
            crop    = vcrop
            lp_conf = 0.0


        # LP embedding
        lpemb = extract_lp_embedding(lp_model, crop, device, fp16)
        lpemb = F.normalize(lpemb.squeeze(0),  dim=-1)
        # confidences
        veh_conf = float(arr[i, 4])

        out.append((vemb, lpemb, veh_conf, lp_conf))
    torch.cuda.empty_cache()
    return out


  
import numpy as np
import torch
import torch.nn.functional as F
from scipy.optimize import linear_sum_assignment
from strongsort import StrongSORT as _BaseStrongSORT
from strongsort.sort.detection import Detection
from strongsort.sort.linear_assignment import (
    matching_cascade,
    min_cost_matching,
    gate_cost_matrix
)
from strongsort.sort.iou_matching import iou_cost

class StrongSORTScoreFusion(_BaseStrongSORT):
    """
    StrongSORT with vehicle+LP fused appearance metric, preserving
    full Kalman gating + multi-round cascade + IOU fallback.
    """

    def __init__(
        self,
        model_weights,
        device,
        max_dist=0.4,
        max_iou_distance=0.7,
        max_age=250,
        n_init=10,
        nn_budget=200,
        fp16=False,
        *,
        veh_model=None,
        lp_model=None,
        w_lp=0.5,
        w_veh=0.5
    ):
        super().__init__(
            model_weights=model_weights,
            device=device,
            max_dist=max_dist,
            max_iou_distance=max_iou_distance,
            max_age=max_age,
            n_init=n_init,
            nn_budget=nn_budget,
            fp16=fp16
        )
        self.device           = device
        self.fp16             = fp16
        self.w_lp, self.w_veh = w_lp, w_veh
        self.veh_model, self.lp_model = veh_model, lp_model
        self.lp_det, self.ocr = initialize_models(device)
        self.mu_v, self.mu_p = 0.0, 0.0
        self.var_v, self.var_p = 1.0, 1.0
        self.alpha = 0.01          # exponential-moving-average factor

    @property
    def tracks(self):
        return self.tracker.tracks

    def _get_features(self, dets, img):
        return lp_get_features_with_weights(
            dets, img,
            veh_model=self.veh_model,
            lp_model=self.lp_model,
            lp_det=self.lp_det,
            ocr=self.ocr,
            device=self.device,
            fp16=self.fp16
        )

    def _matching_cost(self, track, detection):
        # unpack detection�s embeddings + confidences
        veh_emb, lp_emb, _, lp_conf = detection.raw_feats
    
        # build your track-side averages if you have history,
        # otherwise just default to this detection�s embedding
        if getattr(track, "raw_feats", []):
            # collect all past vehicle embeddings
            veh_feats = [f[0] for f in track.raw_feats]
            # collect only confident plate embeddings
            lp_feats  = [f[1] for f in track.raw_feats if f[3] > 0.75]
    
            veh_avg = torch.stack(veh_feats).mean(0)
            # if we have any good plates, average them, else fallback
            lp_avg  = torch.stack(lp_feats).mean(0) if lp_feats else lp_emb
        else:
            veh_avg, lp_avg = veh_emb, lp_emb
    
        # now compute cosine-distance
        d_veh = 1 - F.cosine_similarity(
            veh_avg.unsqueeze(0), veh_emb.unsqueeze(0), dim=1
        ).item()
        d_lp  = 1 - F.cosine_similarity(
            lp_avg.unsqueeze(0),  lp_emb.unsqueeze(0),  dim=1
        ).item()
        
        a = self.alpha
        # update running means
        old_mu_v = self.mu_v
        self.mu_v  = (1 - a)*old_mu_v + a*d_veh
        self.var_v = (1 - a)*self.var_v + a*(d_veh - old_mu_v)**2
        
        # Plate
        old_mu_p = self.mu_p
        self.mu_p  = (1 - a)*old_mu_p + a*d_lp
        self.var_p = (1 - a)*self.var_p + a*(d_lp - old_mu_p)**2
        

    
        eps = 1e-6                     
        z_v = (d_veh - self.mu_v) / math.sqrt(self.var_v + eps)
        z_p = (d_lp  - self.mu_p) / math.sqrt(self.var_p + eps)

    
        # fuse
        if lp_conf > 0.75:              # only trust the plate if confident
            self.gate_calls += 1
            print(f"z_v={z_v:.3f}  z_p={z_p:.3f}  (lp_conf={lp_conf:.2f})")
            return self.w_veh * z_v + self.w_lp * z_p
        return z_v                       # fall back to vehicle only
        

    

    def _match(self, detections):
        """
        1) Mahalanobis gating + multi-round appearance cascade
        2) IOU fallback
        """
        # 1. Kalman predict
        self.tracker.predict()
        tracks = list(self.tracker.tracks)

        # split confirmed vs unconfirmed
        confirmed = [i for i, t in enumerate(tracks) if t.is_confirmed()]
        unconfirmed = [i for i, t in enumerate(tracks) if not t.is_confirmed()]

        # fused appearance gated metric
        def fused_gated_metric(trks, dets, t_idxs, d_idxs):
            M, N = len(t_idxs), len(d_idxs)
            C = np.zeros((M, N), dtype=float)
            for mi, ti in enumerate(t_idxs):
                for ni, di in enumerate(d_idxs):
                    C[mi, ni] = self._matching_cost(trks[ti], dets[di])
            # apply the same Mahalanobis gate StrongSORT uses
            return gate_cost_matrix(
                C, trks, dets, t_idxs, d_idxs
            )

        # 2. appearance cascade
        matches_a, untrk_a, undet = matching_cascade(
            fused_gated_metric,
            self.tracker.metric.matching_threshold,
            self.tracker.max_age,
            self.tracker.tracks,
            detections,
            confirmed
        )

        # 3. IOU on remaining
        iou_candidates = unconfirmed + [
            k for k in untrk_a
            if self.tracker.tracks[k].time_since_update == 1
        ]
        untrk_a = [k for k in untrk_a if self.tracker.tracks[k].time_since_update != 1]
        matches_b, untrk_b, undet = min_cost_matching(
            iou_cost,
            self.tracker.max_iou_distance,
            self.tracker.tracks,
            detections,
            iou_candidates,
            undet
        )

        matches = matches_a + matches_b
        unmatched_tracks = list(set(untrk_a + untrk_b))
        unmatched_dets   = undet

        return matches, unmatched_tracks, unmatched_dets

    def _update_tracks(self, matches, unmatched_dets, unmatched_trks, det_list):
        trks = self.tracker.tracks
        # apply matches
        for ti, di in matches:
            if ti < len(trks):
                trk, det = trks[ti], det_list[di]
                trk.update(det, det.cls, det.conf)
                trk.raw_feats.append(det.raw_feats)

        # misses
        for ti in unmatched_trks:
            if ti < len(trks):
                trks[ti].mark_missed()

        # new tracks
        for di in unmatched_dets:
            det = det_list[di]
            self.tracker._initiate_track(det, det.cls, det.conf)

        # prune
        self.tracker.tracks = [t for t in trks if not t.is_deleted()]

        # update metric
        feats, tids = [], []
        for ti, di in matches:
            if ti < len(self.tracker.tracks):
                feats.append(det_list[di].feature)
                tids.append(self.tracker.tracks[ti].track_id)
        for di in unmatched_dets:
            feats.append(det_list[di].feature)
            tids.append(self.tracker.tracks[-1].track_id)

        if feats:
            self.tracker.metric.partial_fit(
                np.asarray(feats),
                np.asarray(tids),
                active_targets=[t.track_id for t in self.tracker.tracks if t.is_confirmed()]
            )


    def update(self, dets, ori_img, frame_idx):
        self._current_frame_idx = frame_idx
        self.gate_calls = 0

        # fast exit
        if dets is None or (torch.is_tensor(dets) and dets.numel() == 0):
            self.tracker.predict()
            self._update_tracks([], [], [], [])
            print(f"Fused on 0/0 detections")
            return []

        # build Detection list
        arr = dets.detach().cpu().numpy() if torch.is_tensor(dets) else np.asarray(dets)
        x1, y1, x2, y2, confs, cls_ids = (
            arr[:,0], arr[:,1], arr[:,2], arr[:,3],
            arr[:,4], arr[:,5].astype(int)
        )
        tlwh = np.stack([x1, y1, x2-x1, y2-y1], axis=1)

        raw_feats = self._get_features(arr, ori_img)
        det_list = []
        for i, (veh_emb, lp_emb, veh_conf, lp_conf) in enumerate(raw_feats):
            det = Detection(tlwh[i], float(confs[i]), veh_emb)
            det.cls       = torch.tensor(int(cls_ids[i]), device=self.device)
            det.conf      = float(confs[i])
            det.raw_feats = (veh_emb, lp_emb, veh_conf, lp_conf)
            det_list.append(det)

        # init raw_feats
        for t in self.tracks:
            t.raw_feats = getattr(t, "raw_feats", [])

        # match + update
        matches, u_trks, u_dets = self._match(det_list)
        self._update_tracks(matches, u_dets, u_trks, det_list)

        print(f"Fused on {self.gate_calls}/{len(det_list)} detections")

        # return confirmed
        return [
            [*t.to_tlbr(),
             int(t.track_id),
             int(t.cls if hasattr(t, "cls") else 0)]
            for t in self.tracks if t.is_confirmed()
        ]
        

