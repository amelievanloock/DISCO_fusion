# vehicle_tracking.py
import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F


from pathlib import Path
from typing import List, Optional
from dataclasses import dataclass
from typing import List, Dict, Optional
from core.vehicle_detection import VehicleDetection
from core.lp_reid import LPFeatureWrapper
from core.fusion import initialize_models

from TransReID.config.defaults import _C as default_cfg
from TransReID.model import make_model


from strongsort import StrongSORT as _BaseStrongSORT
# Switch to ScoreFusion if requested
from core.fusion import (
    StrongSORTScoreFusion
)
# LP helper loaders
from core.lp_reid import (
    load_lp_reid_model_transreid,
    load_lp_reid_model_fastreid
)

@dataclass
class Track:
    track_id: int
    bbox: List[float]
    original_coords: List[float]
    frame_idx: int
    confidence: float

class VehicleTracker:
    def __init__(
        self,
        reid_weights_path: str,
        strongsort_weights_path: str,
        device: str = 'cuda',
        video_processor=None,
        lp_reid: bool = False,
        lp_model_type: str = 'transreid',
        veh_model_type: str = 'transreid',
        transreid_cfg_path: Optional[str] = "/home/usuaris/imatge/amelie.van.loock/DISCO-opt/TransReID/configs/VeRi/vit_transreid_stride.yml",
        vehicle_transreid_path: Optional[str] = "/mnt/work/users/amelie.van.loock/vit_transreid_veri.pth",
        lp_transreid_path: Optional[str] = "/mnt/work/users/amelie.van.loock/models/TransReID/logs/dataset_converted_experiment/transformer_120.pth",
        lp_fastreid_path: Optional[str] = "/home/usuaris/imatge/amelie.van.loock/DISCO_original/logs/model_final.pth",
        score_fusion: bool = True,
        lp_only: bool = False
    ):
    

    
        self.device = device
        self.video_processor = video_processor
        self.lp_reid = lp_reid
        self.score_fusion = score_fusion
        self.lp_only = lp_only   

        #(1) Vehicle appearance ReID backbone
        if not self.lp_only:
            if veh_model_type == 'ft_net':
                self.reid_model = self._initialize_ft_net(reid_weights_path)
            elif veh_model_type == 'transreid':
                self.reid_model = self._initialize_transreid(
                    transreid_cfg_path, vehicle_transreid_path)
            else:
                raise ValueError(f"Unknown veh_model_type '{veh_model_type}'")
        else:
            self.reid_model = None

        #(2) Licence-plate ReID backbone (optional)
        self.lp_model = None
        if lp_reid:
            num_lp_ids = 90
            if lp_model_type == 'transreid':
                self.lp_model = load_lp_reid_model_transreid(
                    lp_transreid_path, num_lp_ids, torch.device(device)
                )
            else:
                self.lp_model = load_lp_reid_model_fastreid(
                    lp_fastreid_path, num_lp_ids, torch.device(device)
                )
            self.lp_model = self.lp_model.to(device).eval()
            self.lp_det, self.ocr = initialize_models(device)

        #(3) Select proper StrongSORT-derived tracker class
        #    (a) LP-only
        #    (b) Vehicle + LP 
        #    (c) Plain StrongSORT with appearance features only
        kw = {
            'model_weights': Path(strongsort_weights_path),
            'device': device,
            'max_dist': 0.4 if (score_fusion and lp_reid and not lp_only) else 0.3,
            'max_iou_distance': 0.7,
            'max_age': 600,
            'n_init': 20,
            'nn_budget': 600,
            'fp16': False
        }
        
      
        if self.lp_only and self.lp_reid:
            print("Branch: LP-only")
            TrackerClass = _BaseStrongSORT
            self.tracker = TrackerClass(**kw)
            self.tracker.model = LPFeatureWrapper(
                lp_model=self.lp_model,
                lp_det = self.lp_det,
                device = torch.device(device),
                fp16   = False
            )
            self._use_three_arg_update = False
            
        elif (self.score_fusion and self.lp_reid and not self.lp_only):
            print("Branch: Vehicle + LP")
            TrackerClass = StrongSORTScoreFusion
            kw.update({'veh_model': self.reid_model, 'lp_model': self.lp_model, 'w_lp': 0.25, 'w_veh': 0.75})
            self.tracker = TrackerClass(**kw)
            self._use_three_arg_update = True
            
        else:
            print("Branch: Plain StrongSORT with appearance features only")
            TrackerClass = _BaseStrongSORT
            self.tracker = TrackerClass(**kw)
           
            
            self.tracker.model.model = self.reid_model
            self._use_three_arg_update = False
            if veh_model_type == "transreid":
                print("Patching ReID backend for TransReID input size...")
                backend = self.tracker.model  
                from torchvision import transforms

                
                # StrongSORT expects an input size of 128�256, whereas our
                # TransReID backbone was trained on 256�256. We monkey-patch
                # the backend to apply the correct preprocessing steps.
                backend.image_size = (256, 256)
                backend.transforms = [
                    transforms.Resize(backend.image_size),
                    transforms.ToTensor(),
                    transforms.Normalize(
                        mean=backend.pixel_mean,
                        std=backend.pixel_std,
                    ),
                ]
                backend.preprocess = transforms.Compose(backend.transforms)
                orig_forward = backend.forward
                def patched_forward(im_crops):
                    # 1) Call the original forward pass
                    feats = orig_forward(im_crops)
                
                    # 2) Flatten lists of single-element tensors
                    if isinstance(feats, list) and feats and isinstance(feats[0], (list, tuple)) \
                       and all(len(x) == 1 for x in feats):
                        feats = [x[0] for x in feats]
                    
                    if isinstance(feats, list):
                        # If multiple heads, choose which one you want to pick (here we pick the 768-D CLS head)
                        print(f"Number of embedding heads: {len(feats)}")
                        f = feats[0]
                        # if it?s a numpy array, convert
                        import torch, numpy as np
                        if isinstance(f, np.ndarray):
                            f = torch.from_numpy(f).to(backend.device)
                        # if its a Python list, convert
                        elif not isinstance(f, torch.Tensor):
                            f = torch.tensor(f, device=backend.device)
                        else:
                            f = f.to(backend.device)
                        
                        return f
                
                   
                    return feats.to(backend.device) if isinstance(feats, torch.Tensor) else feats
        

                

    def _initialize_ft_net(self, weights_path: str) -> torch.nn.Module:
        from models.vehicle_tracking.model import ft_net
        model = ft_net(576, stride=1)
        state = torch.load(weights_path, map_location='cpu')
        state = {k.replace('module.', ''): v for k,v in state.items()}
        model.load_state_dict({k:v for k,v in state.items() if k in model.state_dict()}, strict=False)
        model.classifier.classifier = torch.nn.Sequential()
        return model.to(self.device).eval()
        
    def _initialize_transreid(self, cfg_path: str, weights_path: str) -> torch.nn.Module:
        print("[initialize_transreid] loading cfg from", cfg_path)
        cfg = default_cfg.clone()
        cfg.merge_from_file(cfg_path)                # YAML with arch + dims
        cfg.MODEL.DEVICE = "cpu"                     # we move it later
        model = make_model(cfg, num_class=576, camera_num=20, view_num=8)
    
        
        ckpt = torch.load(weights_path, map_location="cpu")
        model.load_state_dict(ckpt.get("model", ckpt), strict=False)
        model.base.sie_xishu = 0.0


        if hasattr(model, "classifier"):
            model.classifier = torch.nn.Identity()

        model.eval()
        return model.to(self.device)
        
        
    def update(
        self,
        frame: np.ndarray,
        dets_list: List[VehicleDetection],
        frame_idx: int,
        transformer=None
    ) -> List[Track]:
        # 1) Format detections into the (N, 6) tensor expected by StrongSORT
        if not dets_list:
            dets = torch.empty((0,6), device=self.device)
        else:
            
            arr = np.array([
                [d.bbox[0], d.bbox[1], d.bbox[2], d.bbox[3],
                 d.confidence, 0]
                for d in dets_list
            ], dtype=np.float32)
            
            dets = torch.from_numpy(arr).to(self.device)
            
        # 2) Forward pass through StrongSORT
        if self._use_three_arg_update:
        
            # StrongSORTScoreFusion expects (detections, img, frame_idx)
            raw_tracks = self.tracker.update(dets.cpu(), frame, frame_idx)
            
        else:
        
            # Base StrongSORT expects (detections, img)
            raw_tracks = self.tracker.update(dets.cpu(), frame)
            
        print(f"[VehicleTracker.update] Called {self.tracker.__class__.__name__}.update(...) with "
      f"{len(dets)} detections, frame_idx={frame_idx}, "
      f"_use_three_arg_update={self._use_three_arg_update}")

        # 3) Wrap raw tracker output into typed `Track` objects
        tracks = []
        for t in raw_tracks:
            # bbox is de eerste vier waarden
            bbox = t[:4]
            # inverse-transform naar originele resolutie
            original_coords = self.video_processor.transform_coordinates(
                coords=bbox,
                inverse=True
            )
            # track_id en confidence zijn t[4] en t[5]
            track = Track(
                track_id=int(t[4]),
                bbox=bbox,
                original_coords=original_coords,
                frame_idx=frame_idx,
                confidence=float(t[5])
            )
            tracks.append(track)
            print(f"In update: Track ID={track.track_id}, bbox={track.bbox}, conf={track.confidence:.3f}")
        
        return tracks
