import math
import torch
import torch.nn.functional as F
import numpy as np
import cv2
from PIL import Image
from torchvision import transforms
from TransReID.config import cfg as trans_cfg
from TransReID.model import make_model as make_lp_reid_model
from TransReID.model import make_model
from fastreid.config import get_cfg
from fastreid.modeling import build_model
from typing import Tuple

_PREPROCESS_PIPELINES = {}


# Model loading helpers

def load_lp_reid_model_fastreid(model_path, num_lp_classes, device, fp16=False):
    cfg = get_cfg()
    cfg.merge_from_file("/mnt/work/users/amelie.van.loock/models/fast-reid1/configs/UFPR_ALPR_train.yaml")
    cfg.MODEL.HEADS.NUM_CLASSES = num_lp_classes
    cfg.MODEL.PRETRAIN_PATH = model_path
    model = build_model(cfg)
    ckpt = torch.load(model_path, map_location='cpu').get('model', {})
    model.load_state_dict(ckpt, strict=False)
    model.to(device)
    if fp16: model.half()
    return model.eval()


def make_lp_reid_model(num_lp_classes):
    return make_model(trans_cfg, num_class=num_lp_classes, camera_num=1, view_num=1)


# Positional-embedding resize for ViT-based TransReID

def interpolate_pos_embed(
    old_embed: torch.Tensor,
    new_embed_shape: Tuple[int, int, int],
    img_size: Tuple[int, int],
    patch_size: int
) -> torch.Tensor:
    # Split off CLS token and flatten
    cls_tok     = old_embed[:, :1]                   
    old_patches = old_embed[:, 1:]                  
    _, old_N, C = old_patches.shape

    # Infer grid size of the checkpoint embeddings
    old_grid_h  = int(round(math.sqrt(old_N)))
    old_grid_w  = old_N // old_grid_h

    # Desired grid size from new image dimensions
    H, W        = img_size
    new_grid_h  = H // patch_size
    new_grid_w  = W // patch_size

    # Reshape and bicubic interpolate
    x = old_patches.view(1, old_grid_h, old_grid_w, C).permute(0, 3, 1, 2)
    
    x = F.interpolate(x, size=(new_grid_h, new_grid_w),
                      mode='bicubic', align_corners=False)
    
    x = x.permute(0, 2, 3, 1).reshape(1, new_grid_h * new_grid_w, C)

    return torch.cat([cls_tok, x], dim=1)           

# TransReID model loader with positional-embedding interpolation

def load_lp_reid_model_transreid(
    model_path: str,
    num_lp_classes: int,
    device: torch.device,
    fp16: bool = False
) -> torch.nn.Module:

    # 1) Build the model
    trans_cfg.defrost()
    trans_cfg.MODEL.PRETRAIN_PATH    = model_path
    trans_cfg.MODEL.PRETRAIN_CHOICE  = 'none'
    trans_cfg.MODEL.NAME             = 'transformer'
    trans_cfg.MODEL.TRANSFORMER_TYPE = 'vit_base_patch16_224_TransReID'
    trans_cfg.freeze()

    model = make_lp_reid_model(num_lp_classes)

    # 2) Load checkpoint
    ckpt = torch.load(model_path, map_location='cpu')
    sd   = ckpt.get('state_dict', ckpt)
    # Drop any old cls-token
    sd.pop('base.cls_token', None)

    # 3) Handle pos_embed resizing
    old_embed = sd.get('base.pos_embed', None)
    new_shape = model.state_dict()['base.pos_embed'].shape  # e.g. (1,197,768)

    if old_embed is not None and tuple(old_embed.shape) != tuple(new_shape):
        # 3a) Figure out H,W
        H, W = trans_cfg.INPUT.SIZE_TRAIN  # e.g. [224,224]

        # 3b) Discover patch_size from the model, or fall back to 16
        if hasattr(model, 'patch_embed') and hasattr(model.patch_embed, 'patch_size'):
            p = model.patch_embed.patch_size
            patch_size = p if isinstance(p, int) else p[0]
        else:
            patch_size = 16

        # 3c) Interpolate
        sd['base.pos_embed'] = interpolate_pos_embed(
            old_embed      = old_embed,
            new_embed_shape= new_shape,
            img_size       = (H, W),
            patch_size     = patch_size
        )

    # 4) Load weights (strict=False to allow minor mismatches)
    model.load_state_dict(sd, strict=False)

    # 5) Finalize
    model.to(device)
    if fp16:
        model.half()
    return model.eval()


def preprocess_lp_image(img, size=(384,128), fp16=False):
    if img.dtype!=np.uint8:
        img = (img*255).astype(np.uint8)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) 
    img = cv2.resize(img, (size[1], size[0]))
    key = (size, fp16)
    if key not in _PREPROCESS_PIPELINES:
        _PREPROCESS_PIPELINES[key] = transforms.Compose([
            transforms.ToPILImage(), transforms.ToTensor(),
            transforms.Normalize([0.5]*3,[0.5]*3)
        ])
    t = _PREPROCESS_PIPELINES[key](img)
    if fp16: t = t.half()
    return t.unsqueeze(0)


def extract_lp_embedding(model, crop, device, fp16=False):
    t = preprocess_lp_image(crop, fp16=fp16).to(device)
    with torch.no_grad(): emb = model(t)
    if isinstance(emb, (list,tuple)): emb = emb[0]
    return emb.squeeze(0)
    
    

class LPFeatureWrapper(torch.nn.Module):
    def __init__(self, lp_model: torch.nn.Module, lp_det, device: torch.device, fp16: bool=False):
        super().__init__()
        self.lp_model = lp_model      # TransReID or FastReID LP network
        self.lp_det   = lp_det        # YOLOv8 license-plate detector
        self.device   = device
        self.fp16     = fp16

    def forward(self, crop_batch):
        print(f"[LPFeatureWrapper] Received crop_batch type: {type(crop_batch)}")
        embeddings = []

        # Case 1: crop_batch is a single Tensor [B,3,H,W]
        if isinstance(crop_batch, torch.Tensor):
            B = crop_batch.shape[0]
            # Move it to CPU and convert each slice to a NumPy array
            cpu_batch = crop_batch.detach().cpu()
            for i in range(B):
                img_t = cpu_batch[i]                  # shape [3, H, W]
                # Convert to NumPy: [3,H,W] ? [H,W,3]
                img_np = img_t.numpy()
                if img_np.dtype != np.uint8:
                    img_np = (img_np * 255).astype(np.uint8)
                img_np = np.transpose(img_np, (1, 2, 0))  # [H, W, 3]
                # If it came in as RGB, but your LP-detector expects BGR, do:
                #   img_np = cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)
                # or vice-versa, depending on how StrongSORT crops images.

                emb = self._extract_lp_emb_from_vehicle_crop(img_np)
                embeddings.append(emb)

        # Case 2: crop_batch is a Python list or tuple of length B
        elif isinstance(crop_batch, (list, tuple)):
            for item in crop_batch:
                # Each item might be a torch.Tensor [3,H,W] or a NumPy array [H,W,3].
                if isinstance(item, torch.Tensor):
                    # Move to CPU, convert to numpy
                    img_t = item.detach().cpu()
                    img_np = img_t.numpy()
                    if img_np.dtype != np.uint8:
                        img_np = (img_np * 255).astype(np.uint8)
                    img_np = np.transpose(img_np, (1, 2, 0))  # [H,W,3]
                else:
                    # Assume item is already a NumPy ndarray [H,W,3].
                    img_np = item
                    if img_np.dtype != np.uint8:
                        img_np = (img_np * 255).astype(np.uint8)

                emb = self._extract_lp_emb_from_vehicle_crop(img_np)
                embeddings.append(emb)

        else:
            raise RuntimeError(
                f"LPFeatureWrapper.forward: Expected a Tensor or a list/tuple, but got {type(crop_batch)}"
            )

        # Now embeddings is a Python list of B 1-D tensors (each shape [D]).
        # Stack them into [B, D] and move to device
        out = torch.stack(embeddings, dim=0).to(self.device)
        return out

    def _extract_lp_emb_from_vehicle_crop(self, img_np: np.ndarray) -> torch.Tensor:

        # (1) Run YOLOv8 LP detector on this vehicle crop
        results = self.lp_det(img_np, verbose=False)[0]
        boxes = results.boxes.xyxy.cpu().numpy()   # shape (N_plate, 4)
        confs = results.boxes.conf.cpu().numpy()   # shape (N_plate,)

        if len(boxes) > 0:
            # Choose the highest-confidence plate
            best = int(np.argmax(confs))
            x1, y1, x2, y2 = boxes[best].astype(int)
            plate_crop = img_np[y1:y2, x1:x2]
            print(f"[LPFeatureWrapper] Gedetecteerde LP-box: (x1={x1}, y1={y1}, x2={x2}, y2={y2}), conf={confs[best]:.3f}")
        else:
            # No LP found ? fall back to using the entire vehicle crop
            plate_crop = img_np

        # (2) Preprocess plate crop ? 1�3�384�128 tensor
        plate_tensor = preprocess_lp_image(plate_crop, size=(384, 128), fp16=self.fp16)
        plate_tensor = plate_tensor.to(self.device)

        # (3) Run the LP-ReID model (TransReID or FastReID)
        with torch.no_grad():
            emb = self.lp_model(plate_tensor)   # Output might be [1�D] or a list
            if isinstance(emb, (list, tuple)):
                emb = emb[0]
            emb = emb.squeeze(0)                # Now shape [D]
        emb = F.normalize(emb, dim=-1)            # L2-normalize

        return emb
