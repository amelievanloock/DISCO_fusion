import cv2
import numpy as np
from collections import deque
from dataclasses import dataclass
from typing import Optional, List, Tuple, Dict

@dataclass
class FrameData:
    frame: np.ndarray                     # The actual frame data
    frame_idx: int                        # Frame index in the video
    original_size: Tuple[int, int]        # Original width, height
    current_size: Tuple[int, int]         # Processing width, height
    timestamp: float                      # Frame timestamp in video

class FrameBuffer:
    """
    Manages efficient sequential reading of video frames using a sliding window buffer.
    Implements a buffer to avoid expensive random access operations on video files.
    """
    def __init__(self, video_path: str, buffer_size: int = 64):
        """
        Initialize the frame buffer.

        Args:
            video_path: Path to the video file
            buffer_size: Number of frames to keep in buffer
        """
        self.cap = cv2.VideoCapture(video_path)
        if not self.cap.isOpened():
            raise ValueError(f"Could not open video file: {video_path}")

        self.frame_width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        self.frame_height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.total_frames = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.fps = self.cap.get(cv2.CAP_PROP_FPS)

        self.buffer_size = buffer_size
        self.frame_buffer = deque(maxlen=buffer_size)
        self.frame_indices = deque(maxlen=buffer_size)
        self.current_pos = 0

    def load_next_batch(self) -> bool:
        """
        Load next batch of frames into buffer.
        
        Returns:
            bool: True if frames were loaded, False if end of video
        """
        frames_loaded = 0

        while len(self.frame_buffer) < self.buffer_size:
            ret, frame = self.cap.read()
            if not ret:
                break

            timestamp = self.cap.get(cv2.CAP_PROP_POS_MSEC) / 1000.0
            
            frame_data = FrameData(
                frame=frame,
                frame_idx=self.current_pos,
                original_size=(self.frame_width, self.frame_height),
                current_size=(self.frame_width, self.frame_height),
                timestamp=timestamp
            )

            self.frame_buffer.append(frame_data)
            self.frame_indices.append(self.current_pos)
            
            self.current_pos += 1
            frames_loaded += 1

        return frames_loaded > 0

    def get_frame(self, frame_idx: int) -> Optional[FrameData]:
        """
        Get a specific frame from buffer if available.

        Args:
            frame_idx: Index of the frame to retrieve

        Returns:
            FrameData object if frame is in buffer, None otherwise
        """
        try:
            buffer_idx = self.frame_indices.index(frame_idx)
            return self.frame_buffer[buffer_idx]
        except ValueError:
            return None

    def slide_window(self) -> int:
        """
        Slide the buffer window forward by removing oldest frames.
        
        Returns:
            Number of frames removed
        """
        frames_to_remove = self.buffer_size // 2
        
        for _ in range(frames_to_remove):
            if self.frame_buffer:
                self.frame_buffer.popleft()
                self.frame_indices.popleft()

        return frames_to_remove

    def get_video_info(self) -> Dict:
        """Return basic information about the video."""
        return {
            'width': self.frame_width,
            'height': self.frame_height,
            'total_frames': self.total_frames,
            'fps': self.fps,
            'duration': self.total_frames / self.fps
        }

    def __len__(self) -> int:
        """Get current number of frames in buffer."""
        return len(self.frame_buffer)

    def clear(self):
        """Release resources."""
        self.cap.release()
        self.frame_buffer.clear()
        self.frame_indices.clear()
        
        
class VideoProcessor:
    """
    High-level video processing operations building on the FrameBuffer.
    Handles frame resizing and coordinate transformations while maintaining
    efficient frame reading through the buffer.
    """
    def __init__(self, video_path: str, buffer_size: int = 64, target_height: Optional[int] = 1080):
        """
        Initialize video processor with frame reading and processing capabilities.

        Args:
            video_path: Path to the video file
            buffer_size: Number of frames to keep in buffer
            target_height: Height to resize frames to (None for no resize)
        """
        self.buffer = FrameBuffer(video_path, buffer_size)
        video_info = self.buffer.get_video_info()
        self.original_height = video_info['height']
        self.original_width = video_info['width']
        self.total_frames = video_info['total_frames']
        
        self.target_height = target_height
        if target_height is not None:
            self.scale_factor = target_height / self.original_height
            self.target_width = int(self.original_width * self.scale_factor)
        else:
            self.scale_factor = 1.0
            self.target_width = self.original_width
            self.target_height = self.original_height

    def _resize_frame(self, frame: np.ndarray) -> np.ndarray:
        """
        Resize frame maintaining aspect ratio.
        """    
        return cv2.resize(frame, (self.target_width, self.target_height))

    def process_frame_range(self, start_frame: int,
                          end_frame: int) -> List[FrameData]:
        """
        Process a range of frames with resizing if configured.
        
        Args:
            start_frame: Starting frame index
            end_frame: Ending frame index (exclusive)
            
        Returns:
            List of processed FrameData objects
        """
        processed_frames = []
        current_frame = start_frame
        
        while current_frame < end_frame:
            frame_data = self.buffer.get_frame(current_frame)
            
            if frame_data is None:
                self.buffer.slide_window()
                if not self.buffer.load_next_batch():
                    break
                frame_data = self.buffer.get_frame(current_frame)
                
                if frame_data is None:
                    current_frame += 1
                    continue
            
            if self.scale_factor != 1.0:
                resized_frame = self._resize_frame(frame_data.frame)
                frame_data = FrameData(
                    frame=resized_frame,
                    frame_idx=frame_data.frame_idx,
                    original_size=(self.original_width, self.original_height),
                    current_size=(self.target_width, self.target_height),
                    timestamp=frame_data.timestamp
                )
            
            processed_frames.append(frame_data)
            current_frame += 1
        
        return processed_frames

    def transform_coordinates(self, coords: List[float], inverse: bool = False) -> List[float]:
        """
        Transform coordinates between original and processing resolutions.
        
        Args:
            coords: List of [x1, y1, x2, y2] coordinates
            inverse: If True, transform from processing to original resolution
            
        Returns:
            Transformed coordinates
        """
        scale = 1/self.scale_factor if inverse else self.scale_factor
        return [coord * scale for coord in coords]

    def get_video_info(self) -> Dict:
        """Get video information including processing parameters."""
        info = self.buffer.get_video_info()
        info.update({
            'target_height': self.target_height,
            'target_width': self.target_width,
            'scale_factor': self.scale_factor,
            'processing_resolution': f"{self.target_width}x{self.target_height}"
        })
        return info

    def clear(self):
        self.buffer.clear()